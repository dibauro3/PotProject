package com.example.parkjaeha.firebasetest;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/**
 * Created by parkjaeha on 2017-02-03.
 */

public class LoginActivity  extends AppCompatActivity implements GoogleApiClient.OnConnectionFailedListener{

        private SignInButton mGooglebtn;
        private  static final  int RC_SIGN_IN = 1;
        private GoogleApiClient mGoogleApiClient;
       // private FirebaseAuth mAuth;
        //private FirebaseAuth.AuthStateListener mAuthListener;
       static final int RC_GOOGLE_SIGN_IN = 9001;
       SignInButton mSigninGoogleButton;
       FirebaseAuth mFirebaseAuth;
    FirebaseAuth.AuthStateListener mFirebaseAuthListener;
    private static final String TAG = "LoginActivity";

        private EditText et_email,et_password;
        private Button btn_register,btn_login;
        private DatabaseReference mDatabaseUser;
        private ProgressDialog mProgress;


        protected void  onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_login);

            et_email = (EditText)findViewById(R.id.et_loginemail);
            et_password =(EditText)findViewById(R.id.et_loginpassword);
            btn_login =(Button)findViewById(R.id.btn_login);
            btn_register = (Button)findViewById(R.id.btn_loginregister);
            mProgress = new ProgressDialog(this);

            mDatabaseUser = FirebaseDatabase.getInstance().getReference().child("Users");

            mFirebaseAuth = FirebaseAuth.getInstance();

            mFirebaseAuthListener = new FirebaseAuth.AuthStateListener() {
                @Override
                public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                    FirebaseUser user = firebaseAuth.getCurrentUser();
                    if ( user != null ) {
                        //Intent intent = getIntent();
                        //String name;
                        //name = intent.getExtras().getString("name");
                        Log.d(TAG, "sign in");

                        Intent mainintent = new Intent(LoginActivity.this, MainActivity.class);
                        //mainintent.putExtra("name",name);

                        startActivity(mainintent);
                        finish();
                    }
                    else {
                        Log.d(TAG, "sign out");
                    }

                }
            };
/*
            mAuth = FirebaseAuth.getInstance();


            mAuthListener = new FirebaseAuth.AuthStateListener() {
                @Override
                public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                    if(firebaseAuth.getCurrentUser() !=null){
                        startActivity(new Intent(LoginActivity.this,MainActivity.class));
                    }
                }
            };
*/

            mSigninGoogleButton = (SignInButton) findViewById(R.id.sign_in_google_button);
            mSigninGoogleButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
                    startActivityForResult(signInIntent, RC_GOOGLE_SIGN_IN);
                }
            });

            GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestIdToken(getString(R.string.default_web_client_id))
                    .requestEmail()
                    .build();



            mGoogleApiClient = new GoogleApiClient.Builder(this)
                    .enableAutoManage(this, this)
                    .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                    .build();

/*
            //Google
            mGooglebtn = (SignInButton) findViewById(R.id.sign_in_google_button);

            mGooglebtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(v.isClickable()) {
                        signIn();
                    }

                }
            });

            GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestIdToken(getString(R.string.default_web_client_id))
                    .requestEmail()
                    .build();

            mGoogleApiClient = new GoogleApiClient.Builder(getApplicationContext())
                    .enableAutoManage(this, new GoogleApiClient.OnConnectionFailedListener() {
                        @Override
                        public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

                            Toast.makeText(LoginActivity.this,"You Got an Error",Toast.LENGTH_LONG).show();
                        }
                    })
                    .addApi(Auth.GOOGLE_SIGN_IN_API,gso)
                    .build();

*/

            //Login
            btn_login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(v.isClickable()) {
                        checkLogin();
                    }

                }
            });

            //register
            btn_register.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent regintent = new Intent(LoginActivity.this,RegisterActivity.class);
                    startActivity(regintent);
                }
            });

        }
/*
        @Override
        protected void onStart() {
            super.onStart();
            mAuth.addAuthStateListener(mAuthListener);
        }
    @Override
    protected void onStop() {
        super.onStop();
        if ( mAuthListener != null )
            mAuth.removeAuthStateListener(mAuthListener);
    }


        private  void signIn(){
            Intent signIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
            startActivityForResult(signIntent,RC_SIGN_IN);
        }

    private void FirebaseAuthWithGoogle(GoogleSignInAccount account) {

        AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        Log.d(TAG, "signInWithCredential:onComplete:" + task.isSuccessful());

                        // If sign in fails, display a message to the user. If sign in succeeds
                        // the auth state listener will be notified and logic to handle the
                        // signed in user can be handled in the listener.
                        if (!task.isSuccessful()) {
                            Log.w(TAG, "signInWithCredential", task.getException());
                            Toast.makeText(LoginActivity.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                        }else{
                            mProgress.dismiss();
                            checkUserExist();
                        }
                        // ...
                    }
                });
    }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);

            if(requestCode == RC_SIGN_IN){
                GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);

                mProgress.setMessage("Starting Sign in...");
                mProgress.show();

                if(result.isSuccess()) {

                    // firebaseAuthwithgoogle 대신 사용가능
                      String token = result.getSignInAccount().getIdToken();
                               AuthCredential credential = GoogleAuthProvider.getCredential(token, null);
                               mFirebaseAuth.signInWithCredential(credential);
                    //
                    GoogleSignInAccount account =result.getSignInAccount();
                    FirebaseAuthWithGoogle(account);

                } else {
                    mProgress.dismiss();

                }
            }
        }

*/

        private void checkLogin(){
            String email = et_email.getText().toString().trim();
            String password = et_password.getText().toString().trim();

            if(!TextUtils.isEmpty(email) && !TextUtils.isEmpty(password)){

                mProgress.setMessage("checking...Login");
                mProgress.show();

                mFirebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){

                            mProgress.dismiss();
                            checkUserExist();

                        }else{
                            mProgress.dismiss();
                            Toast.makeText(LoginActivity.this,"Error Login",Toast.LENGTH_LONG).show();
                        }

                    }
                });
            }else{
                Toast.makeText(LoginActivity.this,"빈칸을 채우시오",Toast.LENGTH_LONG).show();

            }
        }

        private void checkUserExist(){

            if(mFirebaseAuth.getCurrentUser() != null) {

                final String user_id = mFirebaseAuth.getCurrentUser().getUid();
                mDatabaseUser.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.hasChild(user_id)) {

                            Intent mainIntent = new Intent(LoginActivity.this, SubActivity.class);
                            mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(mainIntent);


                        } else {
                            Intent setupIntent = new Intent(LoginActivity.this, SetupActivity.class);
                            setupIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(setupIntent);

                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }else{
                Toast.makeText(getApplication(),"mAuth.getCurrentUser가 비어있네"+mFirebaseAuth.getCurrentUser().toString().trim(),Toast.LENGTH_LONG).show();
            }

        }

    @Override
    protected void onStart() {
        super.onStart();
        mFirebaseAuth.addAuthStateListener(mFirebaseAuthListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if ( mFirebaseAuthListener != null )
            mFirebaseAuth.removeAuthStateListener(mFirebaseAuthListener);
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Log.d(TAG, "onConnectionFailed:" + connectionResult);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if ( requestCode == RC_GOOGLE_SIGN_IN ) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            if ( result.isSuccess() ) {
                String token = result.getSignInAccount().getIdToken();
                AuthCredential credential = GoogleAuthProvider.getCredential(token, null);
                mFirebaseAuth.signInWithCredential(credential);
            }
            else {
                Log.d(TAG, "Google Login Failed." + result.getStatus());
            }
        }
    }
}

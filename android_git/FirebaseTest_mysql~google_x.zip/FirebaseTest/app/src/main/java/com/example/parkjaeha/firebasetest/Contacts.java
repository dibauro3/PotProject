package com.example.parkjaeha.firebasetest;

/**
 * Created by parkjaeha on 2017-02-03.
 */

public class Contacts {

    private  String name,water,sun;

    public  Contacts(String name,String water,String sun){

        this.setName(name);
        this.setWater(water);
        this.setSun(sun);

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSun() {
        return sun;
    }

    public void setSun(String sun) {
        this.sun = sun;
    }

    public String getWater() {

        return water;
    }

    public void setWater(String water) {
        this.water = water;
    }

}

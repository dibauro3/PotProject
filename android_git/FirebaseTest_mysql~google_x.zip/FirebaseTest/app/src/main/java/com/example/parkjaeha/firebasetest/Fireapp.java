package com.example.parkjaeha.firebasetest;

import android.app.Application;

import com.firebase.client.Firebase;


/**
 * Created by parkjaeha on 2017-01-30.
 */

public class Fireapp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Firebase.setAndroidContext(this);

    }

}
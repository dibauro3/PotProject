package com.example.parkjaeha.firebasetest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.firebase.client.Firebase;

/**
 * Created by parkjaeha on 2017-01-31.
 */

public class SubActivity extends AppCompatActivity {
    private Button mSendData;

    private Firebase mRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        Firebase.setAndroidContext(this);

        mRef = new Firebase("https://fir-test-dca56.firebaseio.com/Users");

        mSendData = (Button)findViewById(R.id.btn_addSend);

        mSendData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Firebase mRefChild = mRef.child("Name");
                mRefChild.setValue("Parkjaeha");
            }
        });

    }

}
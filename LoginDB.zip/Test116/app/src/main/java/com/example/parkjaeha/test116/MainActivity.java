package com.example.parkjaeha.test116;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.kosalgeek.asynctask.AsyncResponse;
import com.kosalgeek.asynctask.PostResponseAsyncTask;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements AsyncResponse , View.OnClickListener {

    EditText etUsername,etPassword;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername = (EditText) findViewById(R.id.etUsername);
        etPassword = (EditText) findViewById(R.id.etpassword);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

    }

    @Override
    public void processFinish(String result) {
        Toast.makeText(this,result,Toast.LENGTH_LONG).show();
        Intent in = new Intent(this,SubActivity.class);
        startActivity(in);
    }

    @Override
    public void onClick(View v) {
        HashMap postData = new HashMap();
        postData.put("mobile","android");
        postData.put("txtUsername",etUsername.getText().toString());
        postData.put("txtPassword",etPassword.getText().toString());
          PostResponseAsyncTask task = new PostResponseAsyncTask(this,postData);
         task.execute("http://192.168.0.105:81/client/login.php");
    }
}

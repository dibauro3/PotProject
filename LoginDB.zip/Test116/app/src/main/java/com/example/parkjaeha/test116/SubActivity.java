package com.example.parkjaeha.test116;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by parkjaeha on 2017-01-17.
 */

public class SubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
    }
}

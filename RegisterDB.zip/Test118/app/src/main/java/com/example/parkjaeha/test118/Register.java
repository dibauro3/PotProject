package com.example.parkjaeha.test118;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

/**
 * Created by parkjaeha on 2017-01-18.
 */

public class Register extends Activity{
    EditText et_name,et_username,et_password;
    String name,username,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_layout);
        et_name = (EditText)findViewById(R.id.et_rename);
        et_username = (EditText)findViewById(R.id.et_reusername);
        et_password =(EditText)findViewById(R.id.et_repassword);

    }

    public void userReg(View view){

        name = et_name.getText().toString();
        username=et_username.getText().toString();
        password=et_password.getText().toString();
        String method = "register";
        BackgroundTask backgroundTask= new BackgroundTask(this);
        backgroundTask.execute(method,name,username,password);
        finish();
    }

}
